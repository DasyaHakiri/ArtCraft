from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import ArtTool, ArtMaterial, ArtisticSet, EducationalMaterial, GiftCertificate

@admin.register(ArtTool)
class ArtToolAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'phone_number', 'email')
    search_fields = ('name',)
    list_filter = ('price',)

@admin.register(ArtMaterial)
class ArtMaterialAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'phone_number', 'email')
    search_fields = ('name',)
    list_filter = ('price',)

@admin.register(ArtisticSet)
class ArtisticSetAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'phone_number', 'email')
    search_fields = ('name',)
    list_filter = ('price',)

@admin.register(EducationalMaterial)
class EducationalMaterialAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'phone_number', 'email')
    search_fields = ('name',)
    list_filter = ('price',)

@admin.register(GiftCertificate)
class GiftCertificateAdmin(admin.ModelAdmin):
    list_display = ('name', 'amount', 'phone_number', 'email')
    search_fields = ('name',)
    list_filter = ('amount',)
