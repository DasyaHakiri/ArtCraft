"""
URL configuration for artCraft project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='main'),
    path('tools/', views.tools_view, name='tools'),
    path('artistic_materials/', views.artistic_materials_view, name='artistic_materials'),
    path('artistic_sets/', views.artistic_sets_view, name='artistic_sets'),
    path('educational_materials/', views.educational_materials_view, name='educational_materials'),
    path('gift_certificates/', views.gift_certificates_view, name='gift_certificates'),
    path('tools/<int:pk>/', views.tool_detail_view, name='tool_detail'),
    path('art_material_details/<int:pk>/', views.art_material_details_view, name='art_material_detail'),
    path('educational_material_details/<int:pk>/', views.educational_material_detail_view, name='educational_material_detail'),
    path('gift_certificate_details/<int:pk>/', views.gift_certificate_detail_view, name='gift_certificate_detail'),
    path('artistic_set_details/<int:pk>/', views.artistic_set_detail_view, name='artistic_set_detail'),
]