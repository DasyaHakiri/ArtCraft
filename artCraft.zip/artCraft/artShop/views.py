from django.shortcuts import render, get_object_or_404
from .models import ArtTool, ArtMaterial, ArtisticSet, EducationalMaterial, GiftCertificate

def home_view(request):
    return render(request, 'main.html')

def tools_view(request):
    tools = ArtTool.objects.all()
    return render(request, 'tools.html', {'items': tools})

def educational_materials_view(request):
    materials = ArtMaterial.objects.all()
    return render(request, 'educational_materials.html', {'items': materials})

def gift_certificates_view(request):
    certificates = GiftCertificate.objects.all()
    return render(request, 'gift_certificates.html', {'items': certificates})

def artistic_sets_view(request):
    sets = ArtisticSet.objects.all()
    return render(request, 'artistic_sets.html', {'items': sets})

def artistic_materials_view(request):
    materials = ArtMaterial.objects.all()
    return render(request, 'artistic_materials.html', {'items': materials})

def tool_detail_view(request, pk):
    tool = get_object_or_404(ArtTool, pk=pk)
    return render(request, 'tool_detail.html', {'tool': tool})

def art_material_details_view(request, pk):
    material = get_object_or_404(ArtMaterial, pk=pk)
    return render(request, 'art_material_detail.html', {'material': material})

def educational_material_detail_view(request, pk):
    material = get_object_or_404(EducationalMaterial, pk=pk)
    return render(request, 'educational_material_detail.html', {'material': material})

def gift_certificate_detail_view(request, pk):
    certificate = get_object_or_404(GiftCertificate, pk=pk)
    return render(request, 'gift_certificate_detail.html', {'certificate': certificate})

def artistic_set_detail_view(request, pk):
    art_set = get_object_or_404(ArtisticSet, pk=pk)
    return render(request, 'artistic_set_detail.html', {'art_set': art_set})
